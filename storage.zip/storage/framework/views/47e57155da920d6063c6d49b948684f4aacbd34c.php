<ul class="navbar-nav navbar-right">
    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
            <img alt="image" src="../assets/img/avatar/avatar1.png" class="rounded-circle mr-1">
            <div class="d-sm-none d-lg-inline-block">Halo, <?php echo e(auth()->user()->name); ?></div>
        </a>
        <div class="dropdown-menu dropdown-menu-right">
            <div class="dropdown-title">Akun sejak: <?php echo e(auth()->user()->diffforHumanDate(auth()->user()->created_at)); ?></div>
            <a href="<?php echo e(route('settings')); ?>" class="dropdown-item has-icon <?php echo e(Request::segment(2) === 'settings' ? 'active' : ''); ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item has-icon text-danger" href="<?php echo e(route('logout')); ?>" 
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </li>
</ul>
</nav><?php /**PATH C:\inven-bs\resources\views/layouts/stisla/navbar.blade.php ENDPATH**/ ?>