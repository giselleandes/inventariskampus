

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-primary">
        <i class="fas fa-columns"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Total Barang</h4>
        </div>
        <div class="card-body">
          <?php echo e($commodity_count); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-danger">
        <i class="fas fa-fw fa-check-circle"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Kondisi Baik</h4>
        </div>
        <div class="card-body">
          <?php echo e($commodity_condition_good_count); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-warning">
        <i class="fas fa-fw fa-exclamation-circle"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Kondisi Rusak Ringan</h4>
        </div>
        <div class="card-body">
          <?php echo e($commodity_condition_not_good_count); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-danger">
        <i class="fas fa-fw fa-times-circle"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Kondisi Rusak Berat</h4>
        </div>
        <div class="card-body">
          <?php echo e($commodity_condition_heavily_damage_count); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-12 col-md-12 col-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4>Barang Termahal</h4>
      </div>
      <div class="card-body">
        <?php $__currentLoopData = $commodity_order_by_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_by_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="list-unstyled list-unstyled-border">
          <li class="media">
            <!-- <img class="mr-3 rounded-circle" width="50" src="../assets/img/avatar/avatar-1.png" alt="avatar"> -->
            <div class="media-body">
              <button data-id="<?php echo e($order_by_price->id); ?>" class="float-right btn btn-info btn-sm show_modal" data-toggle="modal" data-target="#show_commodity">Detail</button>
              <div class="media-title"><?php echo e($order_by_price->name); ?></div>
              <span class="text-small text-muted">Harga: Rp<?php echo e($order_by_price->indonesian_currency($order_by_price->price)); ?></span>
            </div>
          </li>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="text-center pt-1 pb-1">
          <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-primary btn-lg btn-round">
            Lihat Semua Barang
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.stisla.index', ['title' => 'Admin Dashboard', 'page_heading' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inven-bs\resources\views/home.blade.php ENDPATH**/ ?>